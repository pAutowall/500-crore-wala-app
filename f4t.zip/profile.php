<?php
session_start();
include("connection.php");
if(isset($_POST['foodtype']) && isset($_POST['location']))
{
    $foodtype = $_POST["foodtype"];
    $location = $_POST["location"];
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "loginsystem";
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
    if ($conn->connect_error) {
        die('Could not connect to the database.');
    }
    
    $sql = "INSERT INTO food (foodtype, location) VALUES ( '$foodtype', '$location')";   // Use you own column name from login table
    if (!mysqli_query($conn, $sql)) {
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);
}

$query="select * from food"; 
$result=mysqli_query($con,$query); 


      ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/my-login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <script src="js/cards.js" defer></script>
</head>

<body>
    <!--header area start-->
    <header>
        <div class="left_area">
            <h3>Food4<span>Thought</span></h3>
        </div>
        <div class="right_area">
            <a href="logout.php" class="logout_btn">Logout</a>
        </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <section>
        <div class="sidebar">
            <center>
                <img src="img/FPvkGPgXsAogrsG.jpg" class="profile_image" alt="">
                <h4>
                    Demo User
				</h4>
                
            </center>
            <a href="#"><i class="fas fa-sliders-h"></i><span>Profile</span></a>
            <a href="#"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
            <a href="#popup1"><i class="fas fa-cogs"></i><span>Create Request</span></a>
            <a href="javascript:gclick()"><i class="fas fa-table"></i><span>Create Card</span></a>
            <!-- <a href="#"><i class="fas fa-th"></i><span>ABC</span></a> -->
            <a href="#"><i class="fas fa-info-circle"></i><span>Tracking</span></a>
            
        </div>
        <!--sidebar end-->
    </section>

   



    <div id="box1" class="container-1">
    
    

        </div>


</body>

</html>